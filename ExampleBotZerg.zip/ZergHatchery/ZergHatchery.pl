:- dynamic
self/2,
queueSize/1,
friendly/2,
isMorphing/2,
minerals/1,
unitAmount/2,
gas/1,
supply/2.

amountOfZerglings(Count) :- aggregate_all(count, friendly("Zerg Zergling",_), Count).
amountOfOverlords(Count) :- aggregate_all(count, friendly("Zerg Overlord",_), Count).

enoughZerglings :- amountOfZerglings(Count), Count >50.