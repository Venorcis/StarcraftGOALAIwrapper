:- dynamic
friendly/2,
self/2,
unitAmount/2,
minerals/1,
gas/1,
isMorphing/2.